<footer>
  <p>Hora de Codar &copy; 2020</p>
</footer>
</body>
</html>